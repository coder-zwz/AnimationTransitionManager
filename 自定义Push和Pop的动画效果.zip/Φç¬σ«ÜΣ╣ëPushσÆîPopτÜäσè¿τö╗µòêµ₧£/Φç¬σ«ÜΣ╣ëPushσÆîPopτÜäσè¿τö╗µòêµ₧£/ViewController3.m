//
//  ViewController3.m
//  自定义Push和Pop的动画效果
//
//  Created by zuweizhong  on 16/6/1.
//  Copyright © 2016年 visoft. All rights reserved.
//

#import "ViewController3.h"
#import "UIViewController+UIViewControllerAnimatedTransitioning.h"

@implementation ViewController3
-(void)viewDidLoad
{
    [super viewDidLoad];
    
    self.view.backgroundColor = [UIColor cyanColor];
    
    self.isOriginalAnimation = YES;
    
    
}
@end
